/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.myconcordia.comp5541.scribr.models;

import java.util.Date;

/**
 *
 * @author sarsingh
 */
public class Operations {

    /**
     * @return the operationId
     */
    public int getOperationId() {
        return operationId;
    }

    /**
     * @param operationId the operationId to set
     */
    public void setOperationId(int operationId) {
        this.operationId = operationId;
    }

    /**
     * @return the operatingTypeId
     */
    public int getOperatingTypeId() {
        return operatingTypeId;
    }

    /**
     * @param operatingTypeId the operatingTypeId to set
     */
    public void setOperatingTypeId(int operatingTypeId) {
        this.operatingTypeId = operatingTypeId;
    }

    /**
     * @return the constructId
     */
    public int getConstructId() {
        return constructId;
    }

    /**
     * @param constructId the constructId to set
     */
    public void setConstructId(int constructId) {
        this.constructId = constructId;
    }

    /**
     * @return the createdAt
     */
    public Date getCreatedAt() {
        return createdAt;
    }

    /**
     * @param createdAt the createdAt to set
     */
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    private int operationId;
    private int operatingTypeId;
    private int constructId;
    private Date createdAt;
    public Operations(int operationId, int operatingTypeId, int constructId, Date createdAt){
        this.operationId = operationId;
        this.operatingTypeId = operatingTypeId;
        this.constructId = constructId;
        this.createdAt = createdAt;
    }
}
