package ca.myconcordia.comp5541.scribr.customUIElems;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author sarsingh
 */
public class CheckComboStore {
    String id;
    Boolean state;
    public CheckComboStore(String id, Boolean state){
        this.id = id;
        this.state = state;
    }
}
