/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca.myconcordia.comp5541.scribr.models;

/**
 *
 * @author sarsingh
 */
public class OperationTypes {

    /**
     * @return the operationTypeId
     */
    public int getOperationTypeId() {
        return operationTypeId;
    }

    /**
     * @param operationTypeId the operationTypeId to set
     */
    public void setOperationTypeId(int operationTypeId) {
        this.operationTypeId = operationTypeId;
    }

    /**
     * @return the operationType
     */
    public String getOperationType() {
        return operationType;
    }

    /**
     * @param operationType the operationType to set
     */
    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }
    private int operationTypeId;
    private String operationType;
    public OperationTypes(int operationTypeId, String operationType){
        this.operationTypeId = operationTypeId;
        this.operationType = operationType;
    }
}
